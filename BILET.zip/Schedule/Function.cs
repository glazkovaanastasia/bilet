﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule
{
    public class Function
    {
        //double x = Convert.ToDouble( Console.ReadLine());
        //double y = 0;
        //double R = Convert.ToDouble(Console.ReadLine());

        public double f1(double x)
        {
            double y = x + 3;
            return y;
        }
        public double f2(double x)
        {
            double y = -x/2;
            return y;
        }
        public double f3(double x)
        {
            double y = -2;
            return y;
        }
        public double f4(double x, double r)
        {
            double y = Math.Sqrt(r * r - x * x); 
            return y;
        }

        public string Fun(double x, double r)

        {
            if (x >= -4 && x <= -2)
                return Convert.ToString(f1(x));
            else if (x >= -2 && x <= 4)
                return Convert.ToString(f2(x));
            else if (x >= 4 && x <= 6)
                return Convert.ToString(f3(x));
            else if (x >= 4 && x <= 6)
                return Convert.ToString(f4(x, r));
            return "Нет решения";






        }
    }
   
}
